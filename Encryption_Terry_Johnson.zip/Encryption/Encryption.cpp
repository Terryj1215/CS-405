// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <cassert>    // For assert macro
#include <fstream>    // For file stream operations (ifstream, ofstream)
#include <iomanip>    // For std::put_time
#include <iostream>   // For console input/output (std::cout, std::cerr, std::endl)
#include <sstream>    // For string stream operations (std::stringstream)
#include <ctime>      // For time operations (std::time_t, std::localtime, std::tm)
#include <string>     // For std::string


/// <summary>
/// Encrypt or decrypt a source string using the provided key.
/// This function implements a simple XOR cipher.
/// </summary>
/// <param name="source">Input string to process.</param>
/// <param name="key">Key to use in encryption / decryption. Must not be empty.</param>
/// <returns>Transformed string. Returns an empty string if source or key is empty.</returns>
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    // It's good practice to handle edge cases gracefully in production code.
    // Assertions are for debugging and will terminate the program if conditions are not met.
    // For this assignment, we'll keep the asserts as per the original code,
    // but also add a check to prevent issues if asserts are disabled.
    if (key.empty() || source.empty()) {
        std::cerr << "Warning: Encryption key or source string is empty. Returning empty string." << std::endl;
        return "";
    }

    // Get lengths now instead of calling the function every time inside the loop.
    // Compilers are often smart enough to inline these, but explicit optimization is clear.
    const auto key_length = key.length();
    const auto source_length = source.length();

    // Assert that our input data is good. These will trigger if key_length or source_length is 0.
    assert(key_length > 0 && "Encryption key cannot be empty.");
    assert(source_length > 0 && "Source string cannot be empty.");

    std::string output = source; // Initialize output string with source content

    // Loop through the source string character by character
    for (size_t i = 0; i < source_length; ++i)
    {
        // TODO: student need to change the next line from output[i] = source[i]
        // transform each character based on an xor of the key modded constrained to key length using a mod
        // This is the core XOR encryption/decryption logic.
        // The modulo operator (%) ensures that we cycle through the key characters if the source is longer than the key.
        output[i] = source[i] ^ key[i % key_length];
    }

    // Our output length must equal our source length for correct transformation.
    assert(output.length() == source_length && "Output string length mismatch after encryption/decryption.");

    // Return the transformed string
    return output;
}

/// <summary>
/// Reads the entire content of a text file into a single string.
/// </summary>
/// <param name="filename">The path to the file to read.</param>
/// <returns>A string containing the file's content. Returns an empty string if the file cannot be opened.</returns>
std::string read_file(const std::string& filename)
{
    std::string file_text; // Initialize an empty string to store file content

    // TODO: implement loading the file into a string
    // Use std::ifstream to open the file for reading.
    std::ifstream inputFile(filename);

    // Check if the file was successfully opened.
    if (inputFile.is_open())
    {
        // Use a stringstream to efficiently read the entire file content into file_text.
        // rdbuf() returns a pointer to the stream's buffer, and operator<< reads from it.
        std::stringstream buffer;
        buffer << inputFile.rdbuf();
        file_text = buffer.str();

        inputFile.close(); // Close the file after reading.
    }
    else
    {
        // Print an error message if the file could not be opened.
        std::cerr << "Error: Could not open file for reading: " << filename << std::endl;
        // The function will return an empty string in case of an error.
    }

    return file_text;
}

/// <summary>
/// Extracts the student name from the first line of a given string of data.
/// The student name is assumed to be the text before the first newline character.
/// </summary>
/// <param name="string_data">The input string containing the student name on the first line.</param>
/// <returns>The extracted student name. Returns an empty string if no newline is found or input is empty.</returns>
std::string get_student_name(const std::string& string_data)
{
    std::string student_name;

    // Find the first newline character in the string.
    size_t pos = string_data.find('\n');

    // Check if a newline character was found.
    if (pos != std::string::npos)
    {
        // If found, copy the substring from the beginning up to the newline as the student name.
        student_name = string_data.substr(0, pos);
    }
    // TODO: Consider edge case where there is no newline, or string_data is very short.
    // For this assignment, if no newline, assume the whole string is the name.
    else if (!string_data.empty())
    {
        student_name = string_data;
    }

    return student_name;
}

/// <summary>
/// Saves data to a specified file following a defined format.
/// The format includes student name, timestamp, encryption key, and the data itself.
/// </summary>
/// <param name="filename">The path to the file to save.</param>
/// <param name="student_name">The name of the student.</param>
/// <param name="key">The encryption key used.</param>
/// <param name="data">The data string to save.</param>
void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data)
{
    // TODO: implement file saving
    // file format
    // Line 1: student name
    // Line 2: timestamp (yyyy-mm-dd)
    // Line 3: key used
    // Line 4+: data

    // Use std::ofstream to open the file for writing.
    std::ofstream outputFile(filename);

    // Check if the file was successfully opened.
    if (outputFile.is_open())
    {
        // Get current time for the timestamp.
        std::time_t currentTime = std::time(nullptr);
        std::tm localTimeBuffer; // Buffer for localtime_s

        // Fix: Use localtime_s for safer time conversion
        if (localtime_s(&localTimeBuffer, &currentTime) == 0) // localtime_s returns 0 on success
        {
            // Write data to the file according to the specified format.
            outputFile << student_name << std::endl; // Line 1: student name
            // Line 2: timestamp (yyyy-mm-dd) using std::put_time for formatting.
            outputFile << std::put_time(&localTimeBuffer, "%Y-%m-%d") << std::endl;
            outputFile << key << std::endl;          // Line 3: key used
            outputFile << data << std::endl;         // Line 4+: data
        }
        else
        {
            std::cerr << "Error: Failed to get local time for timestamp." << std::endl;
        }

        outputFile.close(); // Close the file after writing.
    }
    else
    {
        // Print an error message if the file could not be opened for writing.
        std::cerr << "Error: Could not open file for writing: " << filename << std::endl;
    }
}

int main()
{
    std::cout << "Encryption Decryption Test!" << std::endl;

    // Define file names as constants for clarity and easy modification.
    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrypteddatafile.txt";

    // The encryption key. In a real-world banking application, this would NEVER
    // be hardcoded and would be managed securely (e.g., from a secure vault or environment variable).
    // For this assignment, "password" is used as specified in the previous context.
    const std::string key = "password";

    // Read the source data from the input file.
    const std::string source_string = read_file(file_name);

    // Check if the source file was read successfully and contains data.
    if (source_string.empty()) {
        std::cerr << "Error: Source file '" << file_name << "' is empty or could not be read. Exiting program." << std::endl;
        return 1; // Exit with an error code
    }

    // Get the student name from the data file.
    const std::string student_name = get_student_name(source_string);

    // Encrypt the source string using the defined key.
    const std::string encrypted_string = encrypt_decrypt(source_string, key);

    // Save the encrypted string to a file.
    save_data_file(encrypted_file_name, student_name, key, encrypted_string);

    // Decrypt the encrypted string back to its original form using the same key.
    const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

    // Save the decrypted string to a file.
    save_data_file(decrypted_file_name, student_name, key, decrypted_string);

    // Output confirmation messages to the console.
    std::cout << "Read File: " << file_name << std::endl;
    std::cout << "Encrypted To: " << encrypted_file_name << std::endl;
    std::cout << "Decrypted To: " << decrypted_file_name << std::endl;

    // Verify that the original string matches the decrypted string.
    // This assertion confirms the encryption/decryption process was successful.
    assert(source_string == decrypted_string && "Decrypted string does not match original source string!");

    std::cout << "Decryption successful! Original and decrypted content match." << std::endl;

    // Return 0 to indicate successful program execution.
    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu