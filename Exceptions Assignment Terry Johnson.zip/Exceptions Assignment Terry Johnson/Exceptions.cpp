// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept> // Required for std::exception and its derivatives

// Custom exception class derived from std::exception
// This class provides a custom error message via the what() method.
class CustomException : public std::exception {
public:
    // Override the what() method to provide a custom error message
    // noexcept indicates that the function will not throw exceptions.
    // override ensures that this method is overriding a base class method.
    const char* what() const noexcept override {
        return "Custom Exception: Something specific went wrong!";
    }
};

// Function that simulates more custom application logic and is designed to throw a standard exception.
bool do_even_more_custom_application_logic()
{
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // TODO: Throw any standard exception
    // Throwing a std::runtime_error to simulate an unexpected issue within this logic.
    throw std::runtime_error("An error occurred in even more custom application logic.");

    // This line will not be reached because an exception is thrown above.
    return true;
}

// Function that contains custom application logic, including an exception handler and a custom exception throw.
void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    try {
        // Attempt to execute do_even_more_custom_application_logic, which is expected to throw.
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e) {
        // Catching standard exceptions (like std::runtime_error) thrown from do_even_more_custom_application_logic.
        // std::cerr is used for error output.
        std::cerr << "Caught std::exception in do_custom_application_logic: " << e.what() << std::endl;
        // The program continues execution after handling this exception.
    }

    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main
    // Throwing our custom exception (CustomException) to be caught specifically in the main function.
    throw CustomException();

    // This line will not be reached because a custom exception is thrown above.
    std::cout << "Leaving Custom Application Logic." << std::endl;
}

// Function to perform division, includes error checking for division by zero.
float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
    // Check if the denominator is zero.
    if (den == 0) {
        // If division by zero is attempted, throw a std::domain_error.
        // std::domain_error is appropriate when a mathematical operation is performed outside its domain.
        throw std::domain_error("Division by zero is not allowed.");
    }
    return (num / den);
}

// Function that demonstrates calling the divide function with exception handling.
void do_division() noexcept // noexcept indicates this function promises not to throw exceptions outside of itself.
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.
    float numerator = 10.0f;
    float denominator = 0; // Intentionally set to zero to trigger the exception.

    try {
        // Attempt to perform the division.
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::domain_error& e) {
        // Catching the specific std::domain_error thrown by the divide function.
        std::cerr << "Caught division error in do_division: " << e.what() << std::endl;
    }
}

// Main function where the program execution begins. It includes comprehensive exception handling.
int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception
    //  that wraps the whole main function, and displays a message to the console.
    try {
        // Call the functions that might throw exceptions.
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& e) {
        // Catching our specific custom exception. This must be caught before std::exception.
        std::cerr << "Caught CustomException in main: " << e.what() << std::endl;
    }
    catch (const std::exception& e) {
        // Catching any other standard exceptions that might propagate to main.
        // This should be after more specific handlers.
        std::cerr << "Caught std::exception in main: " << e.what() << std::endl;
    }
    catch (...) {
        // Catch-all for any other unhandled exceptions (e.g., non-std::exception derived objects).
        // This is the least specific and should be last.
        std::cerr << "Caught an unknown/unhandled exception in main." << std::endl;
    }

    std::cout << "Program finished gracefully." << std::endl;
    return 0; // Indicate successful program execution.
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
