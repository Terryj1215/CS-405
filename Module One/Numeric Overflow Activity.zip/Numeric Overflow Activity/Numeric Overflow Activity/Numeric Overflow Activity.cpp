// NumericOverflows.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>      // std::cout
#include <limits>        // std::numeric_limits
#include <utility>       // std::pair
#include <type_traits>   // std::is_integral_v, std::is_floating_point_v
#include <cmath>         // std::isinf

/// <summary>
/// Template function to abstract away the logic of:
///   start + (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to add each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>A std::pair where first is the result and second is a bool indicating success (true) or overflow (false)</returns>
template <typename T>
std::pair<T, bool> add_numbers(T const& start, T const& increment, unsigned long int const& steps)
{
    T result = start;
    bool success = true; // Assume success initially

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Comment: Added overflow detection logic before addition.
        // For integral types, check if adding 'increment' would exceed max() or go below min()
        if constexpr (std::is_integral_v<T>) {
            if (increment > 0 && result > std::numeric_limits<T>::max() - increment) {
                // Potential overflow detected for positive increment
                success = false;
                break; // Prevent actual overflow by stopping further additions
            }
            if (increment < 0 && result < std::numeric_limits<T>::min() - increment) {
                // Potential underflow detected for negative increment (effectively subtraction leading to underflow)
                success = false;
                break; // Prevent actual underflow by stopping further additions
            }
        }

        result += increment;

        // Comment: For floating-point types, check for infinity which indicates overflow.
        // Also check if result became negative infinity which can happen if adding a very large negative.
        if constexpr (std::is_floating_point_v<T>) {
            if (std::isinf(result) && increment != 0) { // If increment is 0, result won't become inf due to addition
                success = false;
                break;
            }
        }
    }

    if (!success) {
        // Comment: Return the original 'start' value as a safe indicator for failure,
        // as the addition was prevented from completing correctly.
        return { start, false };
    }
    return { result, true };
}

/// <summary>
/// Template function to abstract away the logic of:
///   start - (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to subtract each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <returns>A std::pair where first is the result and second is a bool indicating success (true) or underflow (false)</returns>
template <typename T>
std::pair<T, bool> subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps)
{
    T result = start;
    bool success = true; // Assume success initially

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Comment: Added underflow detection logic before subtraction.
        // For integral types, check if subtracting 'decrement' would go below min() or exceed max()
        if constexpr (std::is_integral_v<T>) {
            if (decrement > 0 && result < std::numeric_limits<T>::min() + decrement) {
                // Potential underflow detected for positive decrement
                success = false;
                break; // Prevent actual underflow by stopping further subtractions
            }
            if (decrement < 0 && result > std::numeric_limits<T>::max() + decrement) {
                // Potential overflow detected for negative decrement (effectively addition leading to overflow)
                success = false;
                break; // Prevent actual overflow by stopping further subtractions
            }
        }

        result -= decrement;

        // Comment: For floating-point types, check for infinity which indicates extreme underflow or overflow.
        if constexpr (std::is_floating_point_v<T>) {
            if (std::isinf(result) && decrement != 0) { // If decrement is 0, result won't become inf due to subtraction
                success = false;
                break;
            }
            // Note: Detecting "true" floating-point underflow (values becoming denormalized or zero)
            // is more complex and often considered part of normal FP behavior rather than an error
            // to be "prevented" in this context, unless specific precision requirements exist.
            // The primary concern here is overflow to infinity or underflow to negative infinity for large values.
        }
    }

    if (!success) {
        // Comment: Return the original 'start' value as a safe indicator for failure,
        // as the subtraction was prevented from completing correctly.
        return { start, false };
    }
    return { result, true };
}


//  NOTE:
//    You will see the unary ('+') operator used in front of the variables in the test_XXX methods.
//    This forces the output to be a number for cases where cout would assume it is a character.

template <typename T>
void test_overflow()
{
    // TODO: The add_numbers template function will overflow in the second method call
    //       You need to change the add_numbers method to:
    //       1. Detect when an overflow will happen
    //       2. Prevent it from happening
    //       3. Return the correct value when no overflow happened or
    //       4. Return something to tell test_overflow the addition failed
    //       NOTE: The add_numbers method must remain a template in the NumericFunctions header.
    //
    //       You need to change the test_overflow method to:
    //       1. Detect when an add_numbers failed
    //       2. Inform the user the overflow happened
    //       3. A successful result displays the same result as before you changed the method
    //       NOTE: You cannot change anything between START / END DO NOT CHANGE
    //             The test_overflow method must remain a template in the NumericOverflows source file
    //
    // There are more than one possible solution to this problem.
    // The solution must work for all of the data types used to call test_overflow() in main().

    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we add each step (result should be: start + (increment * steps))
    const T increment = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = 0;

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    // Comment: Call add_numbers and capture the std::pair result.
    std::pair<T, bool> add_result;

    std::cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";
    add_result = add_numbers<T>(start, increment, steps);
    // Comment: Check the boolean flag to determine if the operation was successful.
    if (add_result.second)
    {
        std::cout << +add_result.first << " (Overflow Status: false)" << std::endl;
    }
    else
    {
        // This case should ideally not happen for the 'without overflow' test,
        // but the defensive code is in place.
        std::cout << "Operation Failed (Overflow Status: true)" << std::endl;
    }

    std::cout << "\tAdding Numbers With Overflow (" << +start << ", " << +increment << ", " << (steps + 1) << ") = ";
    add_result = add_numbers<T>(start, increment, steps + 1);
    // Comment: Check the boolean flag to determine if the operation was successful.
    if (add_result.second)
    {
        // This path should ideally not be taken for the 'with overflow' test,
        // as the add_numbers function should prevent it and return false.
        std::cout << +add_result.first << " (Overflow Status: false - UNEXPECTED SUCCESS)" << std::endl;
    }
    else
    {
        std::cout << "Operation Failed (Overflow Status: true)" << std::endl;
    }
}

template <typename T>
void test_underflow()
{
    // TODO: The subtract_numbers template function will underflow in the second method call
    //       You need to change the subtract_numbers method to:
    //       1. Detect when an underflow will happen
    //       2. Prevent it from happening
    //       3. Return the correct value when no underflow happened or
    //       4. Return something to tell test_underflow the subtraction failed
    //       NOTE: The subtract_numbers method must remain a template in the NumericFunctions header.
    //
    //       You need to change the test_underflow method to:
    //       1. Detect when an subtract_numbers failed
    //       2. Inform the user the underflow happened
    //       3. A successful result displays the same result as before you changed the method
    //       NOTE: You cannot change anything between START / END DO NOT CHANGE
    //             The test_underflow method must remain a template in the NumericOverflows source file
    //
    // There are more than one possible solution to this problem.
    // The solution must work for all of the data types used to call test_overflow() in main().

    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we subtract each step (result should be: start - (increment * steps))
    const T decrement = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    // Comment: Call subtract_numbers and capture the std::pair result.
    std::pair<T, bool> subtract_result;

    std::cout << "\tSubtracting Numbers Without Overflow (" << +start << ", " << +decrement << ", " << steps << ") = ";
    subtract_result = subtract_numbers<T>(start, decrement, steps);
    // Comment: Check the boolean flag to determine if the operation was successful.
    if (subtract_result.second)
    {
        std::cout << +subtract_result.first << " (Overflow Status: false)" << std::endl;
    }
    else
    {
        // This case should ideally not happen for the 'without underflow' test.
        std::cout << "Operation Failed (Overflow Status: true)" << std::endl;
    }

    std::cout << "\tSubtracting Numbers With Overflow (" << +start << ", " << +decrement << ", " << (steps + 1) << ") = ";
    subtract_result = subtract_numbers<T>(start, decrement, steps + 1);
    // Comment: Check the boolean flag to determine if the operation was successful.
    if (subtract_result.second)
    {
        // This path should ideally not be taken for the 'with underflow' test,
        // as the subtract_numbers function should prevent it and return false.
        std::cout << +subtract_result.first << " (Overflow Status: false - UNEXPECTED SUCCESS)" << std::endl;
    }
    else
    {
        std::cout << "Operation Failed (Overflow Status: true)" << std::endl;
    }
}

void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    // unsigned integers
    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    // real numbers
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Undeflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    // unsigned integers
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    // real numbers
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

/// <summary>
/// Entry point into the application
/// </summary>
/// <returns>0 when complete</returns>
int main()
{
    //  create a string of "*" to use in the console
    const std::string star_line = std::string(50, '*');

    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    // run the overflow tests
    do_overflow_tests(star_line);

    // run the underflow tests
    do_underflow_tests(star_line);

    std::cout << std::endl << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu