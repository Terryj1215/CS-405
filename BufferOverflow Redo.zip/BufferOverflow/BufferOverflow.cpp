// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>    // Required for output formatting (though not strictly used in this fix)
#include <iostream>   // Required for input/output operations (std::cout, std::cin)
#include <string>     // Required for using std::string for safe temporary input storage
#include <limits>     // Required for std::numeric_limits to clear input buffer
#include <cstring>    // Required for std::strncpy_s for safe string copying (replaces strncpy)

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
    //  even though it is a constant and the compiler buffer overflow checks are on.
    //  You need to modify this method to prevent buffer overflow without changing the account_number
    //  variable, and its position in the declaration. It must always be directly before the variable used for input.
    //  You must notify the user if they entered too much data.

    // Declare the constant account number.
    // As per the requirement, its position and type remain unchanged.
    const std::string account_number = "CharlieBrown42";

    // Declare the character array for user input.
    // As per the requirement, its type and size remain unchanged.
    char user_input[20]; // This buffer can hold 19 characters + null terminator

    // Declare a temporary std::string to safely read the user's input.
    // This allows us to read an arbitrary length of input without overflowing
    // a fixed-size buffer, then validate and truncate if necessary.
    std::string temp_input;

    std::cout << "Enter a value: ";

    // Use std::getline to read the entire line of input safely into temp_input.
    // This prevents a buffer overflow at the input stage, as std::string
    // dynamically manages its memory.
    std::getline(std::cin, temp_input);

    // Calculate the maximum number of characters user_input can safely hold.
    // It's the total size of the array minus 1 for the null terminator.
    const size_t max_input_length = sizeof(user_input) - 1;

    // Check if the user entered more data than the buffer can safely hold.
    if (temp_input.length() > max_input_length) {
        // Notify the user that too much data was entered.
        std::cout << "Warning: You entered too much data. Input has been truncated." << std::endl;

        // Safely copy only the allowed number of characters from temp_input to user_input.
        // strncpy_s is the secure version of strncpy. It requires the destination buffer size
        // as an additional argument, which helps prevent buffer overflows.
        // It also guarantees null-termination if the source string fits or is truncated.
        strncpy_s(user_input, sizeof(user_input), temp_input.c_str(), max_input_length);

        // No manual null-termination is needed here because strncpy_s guarantees it
        // if the copy is successful and the buffer is large enough, or if it truncates.
    }
    else {
        // If the input length is within bounds, safely copy the entire string.
        // Use strncpy_s for consistency and safety.
        // The third argument is the number of characters to copy from the source.
        // The fourth argument is the maximum number of characters to copy (including null terminator).
        strncpy_s(user_input, sizeof(user_input), temp_input.c_str(), temp_input.length());

        // No manual null-termination is needed here because strncpy_s guarantees it.
    }

    std::cout << "You entered: " << user_input << std::endl;
    // Verify that the account_number remains unchanged.
    std::cout << "Account Number = " << account_number << std::endl;

    // Clear any leftover newline characters in the input buffer.
    // This is good practice, especially after mixing std::cin operations.
    // In this specific case, since we use std::getline, it consumes the newline,
    // but it's harmless to keep this line for robustness.
    // Note: std::cin.ignore is not strictly needed after std::getline,
    // but it's kept for general robustness in case of other input methods.
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');


    // Pause the console to view the output before closing.
    // This is useful when running the executable directly without an IDE.
    std::cout << "\nPress Enter to exit.";
    std::cin.get(); // Wait for user to press Enter

    return 0; // Indicate successful execution
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
